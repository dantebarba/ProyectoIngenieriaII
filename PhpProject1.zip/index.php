<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
        <!-- Latest compiled and minified JavaScript -->
        <script src="js/jquery-2.1.1.min.js"></script>
        <script>
              function putin(){
                   alert('veeengan wachofooorroooosss');
               }
        </script>
        <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <center>
        <button type="button" class="btn btn-primary" onclick="putin()">Apretame gil</button>
        <?php include 'cacadenacho.php'; ?>
    </center>
</body>
</html>
